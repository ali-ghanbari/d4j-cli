Apache Commons CLI
===================

Welcome to the CLI component of the Apache Commons project.

The information in this file is relevant if you have
downloaded a CLI source distribution.

For testing the project, you will need JUnit (if you use
Maven this will be automatically installed and configured
for you):

  http://www.junit.org

There are two ways to build CLI, either with Ant or Maven 2.

Ant can be found here :

  http://ant.apache.org

and to build and test the system use:

  ant dist

Maven 2 can be found here :

  http://maven.apache.org

and to build and test the system use:

  mvn clean package

The system will build and test itself.

For complete documentation type:

  mvn site

Good luck!

- The Apache Commons Team
